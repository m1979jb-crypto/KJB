# HOP Android 빌드 가이드

## 사전 준비

### 1. Rust Android 타겟 설치
```bash
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android i686-linux-android
cargo install cargo-ndk
```

### 2. Android Studio 설치
- https://developer.android.com/studio 에서 설치
- SDK Manager에서 NDK (Side by side) 27.x 설치
- 환경변수 설정:
  ```bash
  export ANDROID_HOME=$HOME/Android/Sdk
  export NDK_HOME=$ANDROID_HOME/ndk/27.0.11902837
  ```

### 3. Java 17 설치
```bash
# Ubuntu/Debian
sudo apt install openjdk-17-jdk

# macOS
brew install openjdk@17
```

## 빌드 방법

### 의존성 설치
```bash
pnpm install
```

### Android 프로젝트 초기화 (최초 1회)
```bash
cd apps/desktop
pnpm tauri android init
```

### 디버그 APK 빌드
```bash
cd apps/desktop
pnpm tauri android build --debug
```

빌드된 APK 위치:
```
apps/desktop/src-tauri/gen/android/app/build/outputs/apk/universal/debug/app-universal-debug.apk
```

### 릴리즈 APK 빌드 (서명 필요)
```bash
cd apps/desktop
pnpm tauri android build
```

## 개발 (실시간 미리보기)

Android 기기 또는 에뮬레이터를 USB로 연결 후:
```bash
cd apps/desktop
pnpm tauri android dev
```

## 주요 변경사항 (데스크톱 → 모바일)

| 제거된 기능 | 이유 |
|---|---|
| 다중 창 (`create_editor_window`) | Android는 단일 Activity 기반 |
| 파일 탐색기 열기 (`reveal_in_folder`) | 모바일 파일 시스템 구조 다름 |
| 자동 업데이트 (`tauri-plugin-updater`) | 앱스토어가 업데이트 담당 |
| 단일 인스턴스 (`tauri-plugin-single-instance`) | Android에서 지원 안 됨 |
| 창 상태 저장 (`tauri-plugin-window-state`) | 모바일 창 개념 없음 |
| 드래그&드롭 | 터치 기반 인터페이스 |
| macOS 메뉴바 | 모바일 없음 |

| 추가/변경된 기능 | 내용 |
|---|---|
| 파일 저장 경로 | 앱 데이터 디렉터리 자동 사용 |
| 앱 재개 이벤트 | `tauri://resume` 으로 인텐트 파일 처리 |
| Android minSdkVersion | 24 (Android 7.0 이상) |

## 파일 열기 (Android Intent)

Android에서 `.hwp` / `.hwpx` 파일을 HOP으로 열려면
`AndroidManifest.xml`에 intent-filter를 추가해야 합니다.
Tauri android init 실행 후 아래 경로 파일을 수정하세요:

```
apps/desktop/src-tauri/gen/android/app/src/main/AndroidManifest.xml
```

`<activity>` 태그 안에 추가:
```xml
<intent-filter>
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <data android:mimeType="application/x-hwp" />
</intent-filter>
<intent-filter>
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <data android:pathPattern=".*\\.hwp" />
    <data android:mimeType="*/*" />
</intent-filter>
<intent-filter>
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <data android:pathPattern=".*\\.hwpx" />
    <data android:mimeType="*/*" />
</intent-filter>
```
