mod commands;
mod pdf_export;
mod state;

use tauri::{AppHandle, Emitter, Manager};

use commands::{
    check_external_modification, close_document, create_document,
    export_pdf_from_hwp_bytes, mark_document_dirty,
    mutate_document, open_document_with_bytes, query_document,
    render_page_svg, save_hwp_bytes, take_pending_open_paths,
};
use state::AppState;

pub fn run() {
    let app = tauri::Builder::default()
        .manage(AppState::default())
        .plugin(tauri_plugin_log::Builder::new().build())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_store::Builder::default().build())
        .setup(|app| {
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            create_document,
            open_document_with_bytes,
            close_document,
            mark_document_dirty,
            save_hwp_bytes,
            render_page_svg,
            query_document,
            mutate_document,
            export_pdf_from_hwp_bytes,
            check_external_modification,
            take_pending_open_paths,
        ])
        .build(tauri::generate_context!())
        .expect("failed to build HOP mobile app");

    app.run(|_app, _event| {});
}
